function [ line_par, intersect_points,pixelproj, phasorprojim, mask_phasorim] = phasor_image( hist, rp, ip, mask )

%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function uses phasor coordinates to calculate equation of a straight line on which the cloud stretches,
% coordinates of the points where the line intersects the phasor circle,
% and projects each pixel on that line, and displays the projection values as an image.
%INPUT ARGUMENTS
% hist = histogram of phasor plot
% [rp,ip] = images with real and imaginary phasor coordinates
% mask = image with 1 in masked in pixels and 0 in masked out pixels
%  NB : inputs are outputs of function phasorplot in same order
%
%OUTPUT ARGUMENTS
%line_par = slope and offset parameters of the line equation ([beta alpha])
%intersect_points = [x_M1 x_M2;y_M1 y_M2] coordinates for the points M1 and M2 at intersection between line and circle
%pixelproj = projection values for all pixels
%phasorprojim = projection of the phasor points of each pixel onto the
%segment [M1 M2] - NB only pixels within mask
%mask = masked pixels - either returns input mask or as calculated in
%function if no input

%select only pixels within [0 1 0 0.5]

if nargin<4;
    mask_phasorim=transpose(ones(size(rp)));
else,
    mask_phasorim=mask;
end

xpixels=size(ip,1);
ypixels=size(ip,2);

% calculate equation of line from spread of points.
% remove pixels out of mask to calculate line equation
iplist=double(reshape(ip*mask_phasorim,1,xpixels*ypixels));
rplist=double(reshape(rp*mask_phasorim,1,xpixels*ypixels));
phasorcoord=[rplist iplist];
iszero=phasorcoord(:,1)==0;
phasorcoord(iszero,:)=[];

phasorcoord(isnan(phasorcoord))=[];

%get line parameters by solving ip=alpha*rp+beta
line_par=[ones(size(phasorcoord,1),1) phasorcoord(:,1)]\(phasorcoord(:,2));
beta=line_par(1);
alpha=line_par(2);

%get intersection points M1 and M2 between line and circle 
x_M1=((1-2*beta*alpha)+sqrt((2*beta*alpha-1)*(2*beta*alpha-1)-4*(1+alpha*alpha)*(beta*beta)))/(2*(1+alpha*alpha));
x_M2=((1-2*beta*alpha)-sqrt((2*beta*alpha-1)*(2*beta*alpha-1)-4*(1+alpha*alpha)*(beta*beta)))/(2*(1+alpha*alpha));
y_M1=alpha*x_M1+beta;
y_M2=alpha*x_M2+beta;
intersect_points=[x_M1 x_M2;y_M1 y_M2];

%project pixel coordinates on segment [M1 M2]
M1M2=sqrt((x_M1-x_M2)*(x_M1-x_M2)+(y_M1-y_M2)*(y_M1-y_M2));
pixelproj=((rplist-x_M2).*(x_M1-x_M2)+(iplist-y_M2).*(y_M1-y_M2))/M1M2;
pixelproj(pixelproj>M1M2)=0;
pixelproj(pixelproj<0)=0;
phasorprojim=double(transpose(reshape(pixelproj,xpixels,ypixels)).*mask_phasorim);

%show line and intersections on phasor plot
nx=200;ny=200;
sx=-0.1;ex=1.1;sy=-0.1;ey=0.6;

%plot universal circle
figure
x=linspace(0,1,1000);
circ=sqrt(x-x.*x) ;
plot(x,circ)
axis([sx ex sy ey]);
hold on

%plot transforms of pixels
image(sx+(ex-sx)*[0:nx]/nx,sy+(ey-sy)*[0:ny]/ny,(double(hist./max(hist)*64)))
%colormap('parula')
colormap('default')
hold on
plot(x,circ)
xlabel('Real Part')
ylabel('Imaginary Part')
title('Phasor Plot')

%plot line
line_x=linspace(x_M2,x_M1,100);
line_y=alpha.*line_x+beta;
plot(line_x,line_y)
scatter([x_M1 x_M2],[y_M1 y_M2],'MarkerFaceColor','y','MarkerEdgeColor','yellow')


%display pixel phasor projections in image space
H=figure
imagesc(phasorprojim,[0 M1M2])
colormap('default')
title('Phasor Image')
%caxis([0 M1M2])

end


