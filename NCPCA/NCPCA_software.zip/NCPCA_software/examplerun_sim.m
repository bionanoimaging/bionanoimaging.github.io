%% This script runs NC-PCA and phasor analysis on simulated FLIM image
%
% This script reproduces figure 2.b  of the manuscipt
% "Noise-corrected principal component analysis of fluorescence lifetime
% imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
addpath(genpath('C:/Matlab data/DIPimage 2.7'))
dipstart

%% create simulated image (default parameters) - display perfect and noisy
%image : tau1=5 ns ; tau2=1 ns ; 500 photons ; no background .
threshold=0;

[nimg,perfim,perfDec,allimgs]=ModelFLIMdata(256,500,'DoubleExp',[5 1 2.5],0);
%% apply NC-PCA - display eigenvectors and score images
[basis,Eigenvectors,basis, Score_images, mask1, Filtered_image, Poisson_norm ]=NCPCA(nimg,4,'Poisson',threshold);

%% apply phasor analysis - display phasor plot and phasor image
[phasor_hist,realPart,imagPart,mask2]=phasorplot(nimg, 50, threshold, 0, -0.25);
[ line_par, intersect_points,pixelproj, phasorprojim, mask_phasorim]=phasor_image(phasor_hist,realPart,imagPart,mask2);


%% Display score images
figure
H=subplot(1,2,1);
imagesc(double(Score_images(:,:,0)),[min(Score_images(:,:,0)) max(Score_images(:,:,0))]);
colormap(H,'gray')
colorbar()
title('first score image')
J=subplot(1,2,2);
imagesc(double(Score_images(:,:,1)),[min(Score_images(:,:,1)) max(Score_images(:,:,1))]);
colormap(J,'bluewhitered')
colorbar()
title('second score image')

%% calculate alpha values for scores
autocorr_score=alpha(Score_images)
autocorr_phasor=alpha(phasorprojim)