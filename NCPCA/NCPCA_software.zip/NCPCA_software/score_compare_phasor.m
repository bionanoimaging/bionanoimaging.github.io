function [ phasor_rescaled, score_rescaled ] = score_compare_phasor(phasorprojim, score, mask)

%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function re-scales score and phasor images to appear on scale from 0 to 1 and apply
%same threshold to both.
% INPUT ARGUMENTS :
% phasorprojim = phasor image (calculated from phasorplot for example)
% score = score image (calculated from NC_PCA)
% mask = image with 1 in selected pixels and 0 elsewhere
%
% OUTPUT ARGUMENTS :
% phasor_rescaled : rescaled phasor image
% score_rescaled : rescaled score image

xpixels=size(phasorprojim,1);
ypixels=size(phasorprojim,2);

%remove zero pixels to find range of phasor and distance to zero
phasorprojimlist=reshape(phasorprojim, xpixels*ypixels,1);
nonzeros_phasor=phasorprojimlist(phasorprojimlist>0);
nonzeros_phasor(nonzeros_phasor==0)=[];
range_phasor=max(nonzeros_phasor)-min(nonzeros_phasor);
rangetozeroratio=min(nonzeros_phasor)/range_phasor;

% remove zero pixels in score
score=score.*mask;
scorelist=reshape(double(score),xpixels*ypixels,1);
nonzeros_score=scorelist(scorelist~=0);
nonzeros_score(nonzeros_score==0)=[];

%find contrast range of score image and shift up proportionnally to the
%distance to zero of the phasor
range_scores=max(nonzeros_score)-min(nonzeros_score);
newmin=rangetozeroratio*range_scores;
shift=newmin+sqrt(min(nonzeros_score)*min(nonzeros_score));
score=(score+shift)*mask;

%rescale both images on a 0 to 1 color scale
phasor_rescaled=double(phasorprojim./max((max(phasorprojim))));
score_rescaled=double(score./max(score));

%display

subplot(1,2,1)
imagesc(phasor_rescaled,[0 1])
%imshow(phasor_rescaled)
title('phasor image')
%colormap('parula')
colormap('default')
%caxis([0 1]);
colorbar()

subplot(1,2,2)
imagesc(score_rescaled,[0 1])
%imshow(score_rescaled)
title('score image')
%colormap('parula')
colormap('default')
%caxis([0 1]);
colorbar()

end