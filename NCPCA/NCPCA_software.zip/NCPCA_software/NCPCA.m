function [mybasis, Eigenvectors, Scores, mask_ncpca, FiltImg, NoiseCorrection]=NCPCA(mydata, MaxDims, NormType, threshold)

%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function performs NC-PCA on FLIM data.
% INPUT ARGUMENTS
% mydata : Data to find the components from. time data along the 3rd. (default = HeLa cell image, figure 4 from publication)
% MaxDims : maximum dimensions to search through (default = 4)
% NormType :    - '' : no norm (equal variances), 
%               - 'Poisson': NCPCA (default)
%               - 'Variance' : normalize by standard deviations
% threshold : select pixels with threshold value peak time bin (default = 0)
% 
% OUTPUT ARGUMENTS
% mybasis : principal components of scaled data
% Eigenvectors : rescaled principal components
% Scores : the corresponding abundance maps.
% mask_ncpca : if threshold applied; returns 1 in selected pixels and 0 elsewhere
% FiltImg : mydata projected onto the new subspace, so this is a denoised dataset
% NoiseCorrection : noise correction which is applied before PCA
%% Example
% [EV, Scores,mask,FiltImg]=NCPCA(format_raw_data,4,'Poisson',10)

if nargin < 1
    mydata=format_raw_data;
end

if nargin < 2
MaxDims=4;  % Subspace dimension to project to or one more to see if the next component is "just" noise
end

if nargin < 3
    NormType='Poisson';
end

if nargin<4
    threshold=0;
end


%arrange data in 3-D dip_image dataset
if ndims(mydata)==2;
    mydata=reshape(mydata,sqrt(size(mydata,1)),sqrt(size(mydata,1)),size(mydata,2));
end
mydata=dip_image(mydata);

%background estimation
[out,Bg,bg_im]=backgroundoffset(squeeze(mean(mydata(:,:,round(size(mydata,3)/2):size(mydata,3)-1),[],3)));

switch NormType 
% Poisson scaling of data to account for detection noise. Other types for demo only.
    case '' 
        NoiseCorrection=1;
    case 'Poisson' 
        %Scaling factor = square root of average intensity at each time
        %bin.
        NoiseCorrection=sqrt(mean(mydata,[],[1 2])+eps); 
    case 'Variance'
        %Scaling factor = standard deviation at each time bin
        NoiseCorrection=std(mydata,[],[1 2])+eps;
    otherwise
        help
        error('unknown NormType');
end

%find peak - set all pixels below threshold to 0
[maxv,peak_ind]=max(squeeze(mean(mydata,[],[1 2]))); 
mask_ncpca=(mydata(:,:,peak_ind))>threshold;
% The background is removed before the normalization, however, the norm is estimated including the background
mydata=(mydata-round(Bg))*mask_ncpca;

%Image is normalised by scaling factor
mydata_norm = mydata ./ NoiseCorrection;

%image arranged as vectors containing each a decay.
allvecs=transpose(double(reshape(mydata_norm,[size(mydata_norm,1)*size(mydata_norm,2) size(mydata_norm,3)])));

%Data is centered
allvecs_cent=bsxfun(@minus, allvecs,mean(allvecs,1));

%covariance matrix of dataset
myc = (allvecs_cent'*allvecs_cent)/(size(allvecs_cent,1)-1);

%SVD of covariance matrix
[U D V] = svd(transpose(myc));

%Extraction of first desired eigenvectors
mybasis=V(:,1:MaxDims);

%Optional : force positive maximum of Eigenvectors 
for i=1:MaxDims;
   if abs(min(mybasis(:,i)))>abs(max(mybasis(:,i)));
       mybasis(:,i)=-mybasis(:,i);
   end
end

%calculate orthogonal projection of pixel data on the selected eigenvectors
%= pixel scores
projected=transpose(transpose(mybasis)*transpose(allvecs)); 
Scores=reshape(dip_image(transpose(projected)),[size(mydata_norm,1) size(mydata_norm,2) MaxDims]);
          
% Apply reverse scaling to eigenvectors           
if prod(size(NoiseCorrection)) > 1
    Eigenvectors=mybasis .* repmat(transpose(double(squeeze(NoiseCorrection))),[1 size(mybasis,2)]);
else
    Eigenvectors=mybasis .* NoiseCorrection;    
end

%Display NC-PCA results
figure
plot(Eigenvectors)
title('Principal Components')
legend({'PC1','PC2','PC3','PC4'})

Scores

%Filtering 
    DF=D;
    DF(MaxDims+1:end,MaxDims+1:end)=0;
    % Forces all "unwanted" Eigenvalues to be zero and the others to be one. 
    %Thus only a projection onto the subspace is performed.
    for n=1:MaxDims  
        DF(n,n)=1;
    end

    Filtered = (U*(DF*(transpose(V)*transpose(allvecs))));
    FiltImg=reshape(dip_image(Filtered),[size(mydata_norm,1) size(mydata_norm,2) size(Filtered,1)]).* NoiseCorrection;
