function [nimg,perfim,perfDec,allimgs,perfabs, relabs]=ModelFLIMdata(nbtimebins,NPhotons,MyModel,Taus,Bg)

%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function simulates a FLIM dataset with Poisson noise
%
% INPUT ARGUMENTS:
% ntimebins : Number of time points  (default = 256)
% NPhotons : Number of expected photons in the brightes pixel (default = 500, not including the background Bg)
% MyModel : Type of model to simulate. Possible values are
%   'SingleExp' : a single exponential decay  (tau = 5 ns)
%   'DoubleExp' (default) : a double exponential decay, abundances varying between pixels (tau1 = 5 ns, tau2 = 1 ns)
%   'TripleExp' : a triple exponential decay, abundances varying between pixels (tau1 = 5 ns, tau2 = 1 ns, tau3=2.5 ns)
%   'AcceptorRise' : signal from a FRET acceptor with delayed rise time 
% Taus : 1-by-3 vector containing three lifetime values - if only one or 2 are needed give random values or 0 value to the unneeded ones but this argument must be 1-by-3 in size. 
% Bg : Background (in expected photons) (default = 0)
%
% OUTPUT ARGUMENTS
% nimg : noisy dataset. The time dimension is along the 3rd dimension
% perfim : as nimg, but without the poisson noise and without the background
% perfDec : noise free decays
% allimgs : source RGB channel images
% perfabs : absolute abundances of each decay component
% relabs : relative abundances of each decay component

if nargin < 1
    nbtimebins=256;  % Number of timepoints
end
if nargin < 2
    NPhotons=500;  % Average number of photons in the decay
end
if nargin < 3
    MyModel='DoubleExp'; % 1: two single exponentials, 2: 3 single exponentials, 3: multiexponential
end
if nargin < 5
    Bg=0; % Background in photons
end

if nargin<4;
    Taus=[5 1 2.5];
end

if nargin<6;
    ABratio=[1 1 1]; % relative abundance of each image.
end



tau1=Taus(1);
tau2=Taus(3);
tau3=Taus(2);

mytime=linspace(0,50,nbtimebins);
%IRF = gaussian with 235 ps FWHM
irf=normpdf(mytime,1,0.1);

c1=exp(-mytime/tau1);
c2=exp(-mytime/tau2);
c3=exp(-mytime/tau3);
% 
c1i=conv(irf,c1);
c2i=conv(irf,c2);
c3i=conv(irf,c3);

c1c(1,1,1:nbtimebins)=c1i(1:nbtimebins);
c2c(1,1,1:nbtimebins)=c2i(1:nbtimebins);
c3c(1,1,1:nbtimebins)=c3i(1:nbtimebins);

%size(c1c)

tauFRET=1;
kD=1/25.5;
kDET=kD+1/tauFRET;  % Donor and Energy transfer
kA=1/10.5;
cD=exp(-mytime*kD);
cA=1/(tauFRET*(kDET-kA))*(exp(-mytime*kA)-exp(-mytime*kDET));  % Acceptor signal with rise

%display inititial decays
% figure
% plot(double(c1(:)),'r')
% hold on
% plot(double(c2(:)),'g')
% plot(double(c3(:)),'b')
% title('decays of respective components')

switch (2)
    case 1
        a1=readim('pisa');
        a2=readim('orka');
        a3=readim('lena');
    case 2
        a1=readim('C1hela-cells.tif');
        a3=readim('C2hela-cells.tif');
        a2=readim('C3hela-cells.tif');
    case 3
        a1=readim('C1FluorescentCells.tif');
        a2=readim('C2FluorescentCells.tif');
        a3=readim('C3FluorescentCells.tif');
end

% a1=a1(0:255,120:375);
% a2=a2(0:255,120:375);
% a3=a3(0:255,120:375);

switch (MyModel)
    case 'SingleExp'
        perfim=c1c*a1;
        allimgs=a1;
        perfDec=c1c;
        perfabs=allimgs*tau1;
        relabs=perfabs./perfabs
    case 'DoubleExp'
        perfim=c1c*a1+c3c*a3;
        allimgs=cat(3,a1,a3);
        perfDec=[c1c c3c];
        perfabs=allimgs*cat(3,tau1,tau3);
        relabs=cat(3,perfabs(:,:,0)./sum(perfabs,[],3),perfabs(:,:,1)./sum(perfabs,[],3));
    case 'TripleExp'
        perfim=c1c*a1+c2c*a2+c3c*a3;
        allimgs=cat(3,a1,a2,a3);
        perfDec=[c1c c2c c3c];
        perfabs=allimgs*cat(3,tau1,tau3,tau2);
        relabs=cat(3,perfabs(:,:,0)./sum(perfabs,[],3),perfabs(:,:,1)./sum(perfabs,[],3),perfabs(:,:,2)./sum(perfabs,[],3));
    case 'AcceptorRise'
        perfim=(cA+0.1*cD)*a1;
        allimgs=a1;
        perfim=cA*a1+0.1*cD*a2;
        perfDec=cA;
    otherwise
        error('Unkown Model type.')
end

%normalise by average intensity and multiply by desired intensity
perfim_n=perfim*NPhotons/mean(sum(perfim,[],3));
nimg= noise(perfim_n + Bg,'poisson');    
end
