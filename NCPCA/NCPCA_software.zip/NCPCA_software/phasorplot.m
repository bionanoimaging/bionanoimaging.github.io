function [myhist,realPart,imagPart,mask_phasor,ROI]=phasorplot(mydata, T, threshold, doselect, offsetphase)

%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function calculates phasor coordinates of image and displays phasor plot
% INPUT ARGUMENTS
% mydata = a noisy FLIM image (default = HeLa cell image, figure 4 from publication)
% T = the sampling period (e.g 50 ns)
% threshold = minimum intensity in peak of decay (default = 0)
% doselect = select ROI from image before phasor analysis (default = 0)
% offsetphase = compensate for wide IRF by starting projection at later bins  (default = 0)
% after peak - indicate number of bins
% 
% OUTPUT ARGUMENTS
% myhist = histogram of phasor coordinates in phasor space
% [realPart,imagPart] = images with real and imaginary phasor coordinates
% mask_phasor = mask of selected pixels after threshold 
% ROI = mask of selected pixels after ROI selection

if nargin < 1
    mydata=format_raw_data;
end

if nargin<5
    offsetphase=0;
end

if nargin<4
    doselect=0;
end

if nargin<3
    threshold=0;
end

if ndims(mydata)==3;
    mydata=dip_image(mydata);
    nbtimebins=size(mydata,3);
else
    nbtimebins=size(mydata,2); 
    nbpixels=size(mydata,1)
    mydata=dip_image(reshape(mydata,sqrt(nbpixels),sqrt(nbpixels),nbtimebins));
end

if nargin<2
    T=nbtimebins;
end


%average frame
projM=mean(mydata,[],3);
%average decay
projMS=mean(mydata,[],[1 2]);
%size(projMS)
%determine peak and end of decay
[maxv,peak_ind]=max(squeeze(projMS));


%max sub-threshold pixels
mask_phasor=(mydata(:,:,peak_ind))>threshold;
mask_phasor;

%background estimation from end half of decay in empty region
[out,bg,bg_im]=backgroundoffset(squeeze(mean(mydata(:,:,round(size(mydata,3)/2):size(mydata,3)-1),[],3)));
%select image ROI
if doselect
M_int=double(sum(mydata,[],3));
image(M_int);
%  colormap(jet);
    title('intensity image');
    caxis([min(min(M_int)) max(max(M_int))]);       
    ROI=roipoly;      
    mydata=mydata.*ROI;
end

Mbgc=mydata-(bg);

%determine end of decay
end_ind=find(double(projMS)>bg,1,'last')-1;


%set frequency to decay size and phase to decay peak
myramp=dip_image(linspace(0,T,nbtimebins));
omega=2*pi/((end_ind-peak_ind+1)*T/nbtimebins);
phase=omega*(peak_ind+offsetphase)*T/nbtimebins;

% cos and sin matrices
cosmat=reshape(cos(omega*myramp(peak_ind:end_ind)-phase),1,1,end_ind-peak_ind+1);  %easy way, but has troubles with sampling issues
sinmat=reshape(sin(omega*myramp(peak_ind:end_ind)-phase),1,1,end_ind-peak_ind+1);

%calculate summed intensity for each pixel
sumAll=sum(Mbgc(:,:,peak_ind:end_ind),[],3);

%project each decay on cos and sin matrices
realPart=sum(cosmat .* Mbgc(:,:,peak_ind:end_ind),[],3)/sumAll;
imagPart=sum(sinmat .* Mbgc(:,:,peak_ind:end_ind),[],3)/sumAll;

realPart(isnan(realPart))=0;
imagPart(isnan(imagPart))=0;

%create histogram of phasor coordinates
nx=200;ny=200;
sx=-0.1;ex=1.1;sy=-0.1;ey=0.6;
myhist=diphist2d(realPart,imagPart,squeeze(mask_phasor),[sx ex],[sy ey],nx,ny);

%plot universal circle
figure
x=linspace(0,1,100);
circ=sqrt(x-x.*x) ;
plot(x,circ)
axis([sx ex sy ey]);
hold on

%plot transforms of pixels
image(sx+(ex-sx)*[0:nx]/nx,sy+(ey-sy)*[0:ny]/ny,(double(myhist./max(myhist)*64)))
%colormap('parula')
colormap('default')
hold on
plot(x,circ)
xlabel('Real Part')
ylabel('Imaginary Part')
title('Phasor Plot')

%plot representative decay + frequency adapted sin and cos waves
figure
dat=squeeze(mean(Mbgc,[],[1 2]));
plot(myramp,dat/max(dat))
hold on
plot(myramp(peak_ind:end_ind),squeeze(mean(cosmat,[],[1 2])),'g')
plot(myramp(peak_ind:end_ind),squeeze(mean(sinmat,[],[1 2])),'r')
xlabel('Time Bins')
ylabel('Normalized Intensity')
title('representative decay with cos and sin modulations')
legend({'Average decay','cosine modulation','sine modulation'})

end

