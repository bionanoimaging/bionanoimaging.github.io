function [alpha] =alpha(image)

%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function calculates image autocorrelation coefficient at one pixel shift alpha for
%an image or a series of images in the third dimension.


alpha=zeros(size(image,3),1);
image=double(image);
size(image);
xpixels=size(image,2)
ypixels=size(image,1)
if ndims(image)>2;
    for i=1:size(image,3)
        C1=corrcoef([reshape(image(1:ypixels-1,1:xpixels,i),(ypixels-1)*xpixels,1), reshape(image(2:ypixels,1:xpixels,i),(ypixels-1)*xpixels,1)]);
        C2=corrcoef([reshape(image(1:ypixels,1:xpixels-1,i),ypixels*(xpixels-1),1), reshape(image(1:ypixels,2:xpixels,i),ypixels*(xpixels-1),1)]);
        alpha(i,1)=mean([C1(2,1) C2(2,1)]);
    end
else
        %image=transpose(image);
        C1=corrcoef([reshape(image(1:ypixels-1,1:xpixels),(ypixels-1)*xpixels,1), reshape(image(2:ypixels,1:xpixels),(ypixels-1)*xpixels,1)]);
        C2=corrcoef([reshape(image(1:ypixels,1:xpixels-1),ypixels*(xpixels-1),1), reshape(image(1:ypixels,2:xpixels),ypixels*(xpixels-1),1)]);
        alpha=mean([C1(2,1) C2(2,1)]);
end
end





