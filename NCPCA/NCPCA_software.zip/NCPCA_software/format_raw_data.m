function [data_double, data_dip] = format_raw_data(rawdata, nbxpixels, nbypixels, nbtimebins)

%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function extracts FLIM data from a text file-for the format see example file ('example_raw_data') in software package
%
% INPUT ARGUMENTS:
% rawdata = text file containing FLIM data (default=examples_raw_data file)
% nbxpixels and nbypixels = dimensions of the image (default=square root of number of lines in text file)
% nbtimebins = number of time bins in FLIM image (default = number of columns in rawdata file)
%
% OUTPUT ARGUMENTS:
% data_double=FLIM data image in 3 dimensions - 'double' format
% data_dip=FLIM data image in 3 dimensions - 'DIPimage' format

if nargin<1
    rawdata=dlmread('NCPCA_software\example_raw_data',' ',10,0);
end

% format 2D FLIM data matrix into 3D FLIM data matrix
%pixels in rows - decay in columns

if size(rawdata,1)<size(rawdata,2)
    rawdata=transpose(rawdata);
end

if nargin<4;
    nbtimebins=size(rawdata,2);
end

% If no size data is provided the nb of x and y pixels is assumed to be
% equal to the square root of the number of rows.
if nargin<3
    nbxpixels=sqrt(size(rawdata,1));
    nbypixels=sqrt(size(rawdata,1));
end
    
data_double=permute(reshape(rawdata, nbxpixels, nbypixels, nbtimebins),[2 1 3]);
data_dip=dip_image(data_double);

end
