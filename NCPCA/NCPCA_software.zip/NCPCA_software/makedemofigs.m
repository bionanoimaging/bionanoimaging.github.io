function [demofigs]=makedemofigs(int1, int2, var)

% %% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function makes demo figures for effect of noise on PCA. Two intensity bins, images
%are random arrays of intensity values
% input argumentd
% int1= intensity for image1 - first bin
% int2= intensity for image2 - second bin
% var= variance in the case of Gaussian noise.
% the two noise-free
% images are perfetly correlated.

if nargin<4
    var=1.5;
end

if nargin<3
    int2=30;
end

if nargin<2
    int1=10;
end

%load random number generator seed
load('rng_seed.mat');


%make images from random number generator
rng(rng_seed);
x=dip_image(randi([int2/2 3*int2/2], [128 128]))
y=round(x*int1/int2);

%make two 1-point arrays for the uncorrelated data figure
z=int1*ones(128,128);
w=int2*ones(128,128);

xd=dip_image(x);
yd=dip_image(y);
zd=dip_image(z);
wd=dip_image(w);

%Add Poisson or Gaussian noise
xd_g=noise(xd,'gaussian',var);
yd_g=noise(yd,'gaussian',var);
zd_g=noise(zd,'gaussian',var);
wd_g=noise(wd,'gaussian',var);
xd_p=noise(xd,'poisson');
yd_p=noise(yd,'poisson');
zd_p=noise(zd,'poisson');
wd_p=noise(wd,'poisson');

% normalise noisy and non-noisy data by sqrt(mean) or std of the noisy data
%non-noisy
xd_pnorm=xd/sqrt(mean(xd_p));
yd_pnorm=yd/sqrt(mean(yd_p));
xd_vnorm=xd/std(xd_p);
yd_vnorm=yd/std(yd_p);

%noisy
xdp_pnorm=xd_p/sqrt(mean(xd_p));
ydp_pnorm=yd_p/sqrt(mean(yd_p));
xdp_vnorm=xd_p/std(xd_p);
ydp_vnorm=yd_p/std(yd_p);


%Do SVDs on unscaled data
[u d v]=svd(cov([transpose(double(reshape(xd,128*128))) transpose(double(reshape(yd,128*128)))]));
[ug dg vg]=svd(cov([transpose(double(reshape(xd_g,128*128))) transpose(double(reshape(yd_g,128*128)))]));
[uzg dzg vzg]=svd(cov([transpose(double(reshape(wd_g,128*128))) transpose(double(reshape(zd_g,128*128)))]));
[up dp vp]=svd(cov([transpose(double(reshape(xd_p,128*128))) transpose(double(reshape(yd_p,128*128)))]));
[uzp dzp vzp]=svd(cov([transpose(double(reshape(wd_p,128*128))) transpose(double(reshape(zd_p,128*128)))]));


%Corrected SVDs
%noisy
cov([transpose(double(reshape(xdp_vnorm,128*128))) transpose(double(reshape(ydp_vnorm,128*128)))]);
[up_vn dp_vn vp_vn]=svd(cov([transpose(double(reshape(xdp_vnorm,128*128))) transpose(double(reshape(ydp_vnorm,128*128)))]));
[up_pn dp_pn vp_pn]=svd(cov([transpose(double(reshape(xdp_pnorm,128*128))) transpose(double(reshape(ydp_pnorm,128*128)))]));

%non noisy
[u_vn d_vn v_vn]=svd(cov([transpose(double(reshape(xd_vnorm,128*128))) transpose(double(reshape(yd_vnorm,128*128)))]));
[u_pn d_pn v_pn]=svd(cov([transpose(double(reshape(xd_pnorm,128*128))) transpose(double(reshape(yd_pnorm,128*128)))]));


%Rescale the EVs by normalisation factor
vp_pn_rescaled=vp_pn.*repmat([sqrt(mean(xd_p)) sqrt(mean(yd_p))],[2 1]);
vp_vn_rescaled=vp_vn.*repmat([std(xd_p) std(yd_p)],[2 1]);

v_pn_rescaled=v_pn.*repmat([sqrt(mean(xd_p)) sqrt(mean(yd_p))],[2 1]);
v_vn_rescaled=v_vn.*repmat([std(xd_p) std(yd_p)],[2 1]);

%Display
mag=max([int1 int2]);

demofigs=figure
%reminder quiver : quiver(x,y,u,v) - (x,y)=coordinates for arrow base.
%(u,v)=coefficients on x and y axis, respectively, of the arrow vector.
% noise-free correlation + PC
subplot(4,2,1)
quiver(mean(xd),mean(yd),mag,mag*(v(1,2)/v(1,1)),'black','Linewidth',1.5,'MaxHeadSize',0.5)
hold on
scatter(transpose(double(reshape(xd,128*128))), transpose(double(reshape(yd,128*128))),'.','SizeData',36,'MarkerEdgeColor',[0.64 0.08 0.18]);
xlabel('I_{1}')
ylabel('I_{2}')
set(gca,'FontSize',16,'FontName','Calibri')
axis([0 2*max(xd) 0 2*max(yd)])

% same underlying correlation with Gaussian noise + PC Uncorrected
subplot(4,2,2)
scatter(transpose(double(reshape(xd_g,128*128))), transpose(double(reshape(yd_g,128*128))),'.','SizeData',10,'MarkerEdgeColor',[0.47 0.67 0.19]);
hold on
quiver(mean(xd),mean(yd),mag,mag*(v(1,2)/v(1,1)),'black','Linewidth',1.5,'MaxHeadSize',0.5)
quiver(mean(xd_g),mean(yd_g),mag,mag*(vg(1,2)/vg(1,1)),'Linewidth',1.5,'Color',[0.85 0.33 0.1],'MaxHeadSize',0.5)
xlabel('I_{1}')
ylabel('I_{2}')
set(gca,'FontSize',16,'FontName','Calibri')
axis([0 2*max(xd) 0 2*max(yd)])

% same underlying correlation with Poisson noise + PC Uncorrected
subplot(4,2,4)
scatter(transpose(double(reshape(xd_p,128*128))), transpose(double(reshape(yd_p,128*128))),'.','SizeData',10);
hold on
quiver(mean(xd),mean(yd),mag,mag*(v(1,2)/v(1,1)),'black','Linewidth',1.5,'MaxHeadSize',0.5)
quiver(mean(xd_p),mean(yd_p),mag,mag*(vp(1,2)/vp(1,1)),'Linewidth',1.5,'Color',[0.85 0.33 0.1],'MaxHeadSize',0.5)
xlabel('I_{1}')
ylabel('I_{2}')
set(gca,'FontSize',16,'FontName','Calibri')
axis([0 2*max(xd) 0 2*max(yd)])

% No underlying correlation with Poisson and Gaussian noise
subplot(4,2,3)
scatter(transpose(double(reshape(wd_p,128*128))), transpose(double(reshape(zd_p,128*128))),'.','SizeData',10);
hold on
scatter(transpose(double(reshape(wd_g,128*128))), transpose(double(reshape(zd_g,128*128))),'.','SizeData',10,'MarkerEdgeColor',[0.47 0.67 0.19]);
scatter(transpose(double(reshape(wd,128*128))), transpose(double(reshape(zd,128*128))),'.','SizeData',10);
quiver(mean(wd_p),mean(zd_p),0.5*mag*((dzp(1,1)-dzp(2,2))/(dzp(2,2))),0.5*(vzp(1,2)*mag/vzp(1,1))*(dzp(1,1)-dzp(2,2))/(dzp(2,2)),'Linewidth',1.5,'Color',[0.85 0.33 0.1],'MaxHeadSize',0.5)
quiver(mean(wd_g),mean(zd_g),0.5*mag*((dzg(1,1)-dzg(2,2))/(dzg(2,2))),0.5*(vzg(1,2)*mag/vzg(1,1))*((dzg(1,1)-dzg(2,2))/(dzg(2,2))),'black','Linewidth',1.5,'MaxHeadSize',0.5)
xlabel('I_{1}')
ylabel('I_{2}')
set(gca,'FontSize',16,'FontName','Calibri')
axis([0.8*min(wd_p) 2*max(wd_p) 0.8*min(zd_p) 2*max(zd_p)])

subplot(4,2,5)
%Poisson noisy cloud scaled with std + underlying correlation scaled with
%std + recovered PCs on scaled data, noisy and non-noisy
scatter(transpose(double(reshape(xdp_vnorm,128*128))), transpose(double(reshape(ydp_vnorm,128*128))),'.','SizeData',10);
hold on
scatter(transpose(double(reshape(xd_vnorm,128*128))), transpose(double(reshape(yd_vnorm,128*128))),'.','SizeData',36,'MarkerEdgeColor',[0.64 0.08 0.18]);
%corresponding PCs
quiver(mean(xdp_vnorm),mean(ydp_vnorm),mag/std(xd_p),mag/std(xd_p)*(vp_vn(1,2)/vp_vn(1,1)),'Linewidth',1.5,'Color',[0.85 0.33 0.1],'MaxHeadSize',0.5)
quiver(mean(xd_vnorm),mean(yd_vnorm),mag/std(xd_p),mag/std(xd_p)*(v_vn(1,2)/v_vn(1,1)),'black','Linewidth',1.5,'MaxHeadSize',0.5)
%Underlying correlation, scaled as the cloud
xlabel('I_{1}/\sigma(I_1)')
ylabel('I_{2}/\sigma(I_2)')
set(gca,'FontSize',16,'FontName','Calibri')
axis([0 2*max(xd_vnorm) 0 2*max(yd_vnorm)])

subplot(4,2,6)
%Poisson noisy cloud scaled with Poisson + underlying correlation scaled with
%Poisson + recovered PCs on scaled data, noisy and non-noisy
scatter(transpose(double(reshape(xdp_pnorm,128*128))), transpose(double(reshape(ydp_pnorm,128*128))),'.','SizeData',10);
hold on
%scaled noise-free data
scatter(transpose(double(reshape(xd_pnorm,128*128))), transpose(double(reshape(yd_pnorm,128*128))),'.','SizeData',36,'MarkerEdgeColor',[0.64 0.08 0.18]);
%corresponding PCs
quiver(mean(xdp_pnorm),mean(ydp_pnorm),mag/sqrt(mean(xd_p)),mag/sqrt(mean(xd_p))*(vp_pn(1,2)/vp_pn(1,1)),'Linewidth',1.5,'Color',[0.85 0.33 0.1],'MaxHeadSize',0.5)
quiver(mean(xd_pnorm),mean(yd_pnorm),mag/sqrt(mean(xd_p)),mag/sqrt(mean(xd_p))*(v_pn(1,2)/v_pn(1,1)),'black','Linewidth',1.5,'MaxHeadSize',0.5)
%quiver(mean(xdp_pnorm),mean(ydp_pnorm),mag,mag*(vp_pn(1,2)/vp_pn(1,1)),'Linewidth',1.5,'Color',[0.85 0.33 0.1],'MaxHeadSize',0.5)
%quiver(mean(xd_pnorm),mean(yd_pnorm),mag,mag*(v_pn(1,2)/v_pn(1,1)),'black','Linewidth',1.5,'MaxHeadSize',0.5)
xlabel('I_1/\surd(I_{1avg})')
ylabel('I_2/\surd(I_{2avg})')
set(gca,'FontSize',16,'FontName','Calibri')
axis([0 2*max(xd_pnorm) 0 2*max(yd_pnorm)])

subplot(4,2,7)
%Poisson noisy cloud + underlying correlation + recovered PC after variance scaling 
scatter(transpose(double(reshape(xd_p,128*128))), transpose(double(reshape(yd_p,128*128))),'.','SizeData',10);
hold on
scatter(transpose(double(reshape(xd,128*128))), transpose(double(reshape(yd,128*128))),'.','SizeData',36,'MarkerEdgeColor',[0.64 0.08 0.18]);
quiver(mean(xd),mean(yd),mag,mag*(v(1,2)/v(1,1)),'black','Linewidth',1.5,'MaxHeadSize',0.5)
quiver(mean(xd_p),mean(yd_p),mag,mag*(vp_vn_rescaled(1,2)/vp_vn_rescaled(1,1)),'Linewidth',1.5,'Color',[0.85 0.33 0.1],'MaxHeadSize',0.5)
axis([0 2*max(xd) 0 2*max(yd)])
xlabel('I_{1}')
ylabel('I_{2}')
set(gca,'FontSize',16,'FontName','Calibri')

subplot(4,2,8)
%Poisson noisy cloud + underlying correlation + recovered PC after Poisson scaling 
scatter(transpose(double(reshape(xd_p,128*128))), transpose(double(reshape(yd_p,128*128))),'.','SizeData',10);
hold on
scatter(transpose(double(reshape(xd,128*128))), transpose(double(reshape(yd,128*128))),'.','SizeData',36,'MarkerEdgeColor',[0.64 0.08 0.18]);
quiver(mean(xd),mean(yd),mag,mag*(v(1,2)/v(1,1)),'black','Linewidth',1.5,'MaxHeadSize',0.5)
quiver(mean(xd_p),mean(yd_p),mag,mag*(vp_pn_rescaled(1,2)/vp_pn_rescaled(1,1)),'Linewidth',1.5,'Color',[0.85 0.33 0.1],'MaxHeadSize',0.5)
axis([0 2*max(xd) 0 2*max(yd)])
xlabel('I_{1}')
ylabel('I_{2}')
set(gca,'FontSize',16,'FontName','Calibri')

