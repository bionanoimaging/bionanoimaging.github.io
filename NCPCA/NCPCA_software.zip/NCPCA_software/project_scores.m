function [score_image, roi, score_line]=project_scores(basis,newdata,threshold,doselect)

%% User must have DIP_image image processing toolbox, which can be obtained at 
% http://www.diplib.org
% our software is made available under the Gnu Public Licence Version II (GPL2)
% No warranty of any kind is given and users use it at their own risk.
% Authors of the software: Rainer Heintzmann (heintzmann@gmail.com), Alix
% Le Marois (alix_le_marois@live.fr)
% You may need to add the path to the dipimage installation folder similar to the following line:
% addpath('C:\Program Files\DIPimage 2.7')
%% Please refer to and cite where appropriate: "Noise-corrected principal
% component analysis of fluorescence lifetime imaging (FLIM) data" (2016)
% by Alix Le Marois, Simon Labouesse, Klaus Suhling, and Rainer Heintzmann
%
%% This function uses a pre-formed PCA basis and calculates scores for new
%data to project in.
% INPUT ARGUMENTS : 
% basis : Set of eigenvectors on which to project the data ATTENTION :
% basis is pre-reverse scaling (so basis is properly orthogonal)
% newdata : FLIM image to project in existing basis
% threshold : select pixels with peak value above threshold (default = 0)
% doselect : select ROI in image
%
% OUTPUT ARGUMENTS
% score iamge : score image of data projection in basis
% roi : image with 1 in selected ROI pixels and 0 elsewhere
% score_line : scores of pixels above threshold and in ROI (for histogramming or representation in score space)

MaxDims=size(basis,2);

if ndims(newdata)==2;
    newdata=reshape(newdata,sqrt(size(newdata,1)),sqrt(size(newdata,1)),size(newdata,2));
end

newdata=dip_image(newdata);

if nargin<3
    threshold=0;
end

%Poisson noise correction
NoiseCorrection=sqrt(mean(newdata,[],[1 2])+eps);
[~,Bg,~]=backgroundoffset(squeeze(mean(newdata(:,:,round(size(newdata,3)/2):size(newdata,3)-1),[],3)));
newdata=newdata-round(Bg);  % The background is remove before the normalization, however, the norm is estimated including the background
%select=mydata;

%select ROI
if doselect==1;
    dip_image(sum(newdata,[],3))
    colormap(parula)
    roi=roipoly;
    newdata=newdata*roi;
end

%find peak - set all pixels below threshold to 0
[~,peak_ind]=max(squeeze(mean(newdata,[],[1 2])));
mask=(newdata(:,:,peak_ind))>threshold;

normImg = newdata ./ NoiseCorrection;

allvecs=transpose(double(reshape(normImg,[size(normImg,1)*size(normImg,2) size(normImg,3)])));

%project data in basis
projected=transpose(transpose(basis)*transpose(allvecs));
score_image=reshape(dip_image(transpose(projected)),[size(normImg,1) size(normImg,2) MaxDims])*mask;

%remove zeros for scattering / histogramming
score_line=transpose(double(reshape(score_image,size(normImg,1)*size(normImg,2),MaxDims)));
iszero=((score_line(:,1)==0));
score_line(iszero,:)=[];

end

